number = int(input("Enter number: "))
factorial = 1
i = 1
while i <= number:
    factorial = factorial * i
    i += 1
print(factorial)