#write a function that take user name as an input and print greeetings to that person
#when it is called

def greet(name):
    print("Hello", name)

name = input("Enter your name: ")
greet(name)
greet("Ali")
greet("Ahmed")
greet("Asad")

